from distutils.core import setup

setup(
    name = 'ch08_myclient_volnet',
    version = '1.0.0',
    py_modules = ['myclient'],
    author = 'volnet',
    author_email = 'volnet@tom.com',
    url = 'http://volnet.github.io',
    description='learn how to create a new http client',
)
