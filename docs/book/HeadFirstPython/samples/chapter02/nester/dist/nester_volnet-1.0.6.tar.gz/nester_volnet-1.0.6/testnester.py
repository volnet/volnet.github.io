import nester
this_list = ['a', 'b', ['c', ['d', 'e'], 'f']]

nester.print_list(this_list)
nester.print_list(this_list, True)
nester.print_list(this_list, True, 2)