def getinfo():
    import os
    print(os.getcwd())
    os.chdir("../Documents/")
    #os.chdir("../Dropbox/Documents/个人/volnet.github.io/docs/book/HeadFirstPython/samples/chapter03/")
    print(os.getcwd())

    data = open('sketch.txt')
    print(data.readline(), end='')
    print(data.readline(), end='')

    data.seek(0)
    for each_line in data:
        print(each_line, end='')

    data.close()