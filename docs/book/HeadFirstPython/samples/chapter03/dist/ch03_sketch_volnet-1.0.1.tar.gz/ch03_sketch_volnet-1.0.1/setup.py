from distutils.core import setup

setup(
    name = 'ch03_sketch_volnet',
    version = '1.0.1',
    py_modules = ['sketch'],
    author = 'volnet',
    author_email = 'volnet@tom.com',
    url = 'http://volnet.github.io',
    description='learn how to open file',
)
