from distutils.core import setup

setup(
    name = 'ch05_myclass_volnet',
    version = '1.0.0',
    py_modules = ['myclass'],
    author = 'volnet',
    author_email = 'volnet@tom.com',
    url = 'http://volnet.github.io',
    description='learn how to create a new class',
)
