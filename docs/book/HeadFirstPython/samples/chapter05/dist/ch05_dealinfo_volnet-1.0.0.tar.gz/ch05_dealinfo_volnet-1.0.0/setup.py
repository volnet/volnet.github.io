from distutils.core import setup

setup(
    name = 'ch05_dealinfo_volnet',
    version = '1.0.0',
    py_modules = ['deal'],
    author = 'volnet',
    author_email = 'volnet@tom.com',
    url = 'http://volnet.github.io',
    description='learn how to deal with storage',
)
