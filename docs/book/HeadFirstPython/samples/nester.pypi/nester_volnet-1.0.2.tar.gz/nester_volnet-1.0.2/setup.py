from distutils.core import setup

setup(
    name = 'nester_volnet',
    version = '1.0.2',
    py_modules = ['nester'],
    author = 'volnet',
    author_email = 'volnet@tom.com',
    url = 'http://volnet.github.io',
    description='A simple printer of nested lists',
)